
# BMB CI Pack — GitHub Actions + Playwright

## Як використати (дуже просто)
1) Завантаж цей архів і **розпакуй у корінь репозиторію** (де package.json).
   В результаті у тебе з’являться:
   - `bmb-playwright/` — тести
   - `.github/workflows/bmb-e2e.yml` — CI-флоу

2) На GitHub у репозиторії зайди в **Settings → Secrets and variables → Actions → New repository secret** і додай:
   - `SUPABASE_URL` — твій URL
   - `SUPABASE_SERVICE_ROLE` — сервісний ключ (лише в DEV, не коміть)
   - `SCENARIO_ID` — ID тестового сценарію (для E2E)

3) Готово. Кожен **push/PR** автоматично:
   - встановить залежності
   - збере білд
   - підніме локальний preview
   - прогонить Playwright-тести
   - збере звіт у **Artifacts** (скріни/відео/trace)

4) (Опційно) Вручну запустити проти зовнішнього URL:
   - Actions → **BMB E2E → Run workflow** → в поле `base_url` введи свою адресу (наприклад, `https://dev.bmb.app`)

## Примітки
- Секрети не потрапляють у логи за замовчуванням. Не зберігай ключі в коді.
- Якщо проєкт не Vite, змінити команду та порт у `bmb-playwright/playwright.config.ts` і `bmb-e2e.yml`.
