
# BMB Playwright Suite (CI-friendly)

- Local run:
  ```bash
  cd bmb-playwright
  npm i -D @playwright/test
  npx playwright install
  BASE_URL=http://localhost:4173 npx playwright test
  ```

- Uses `BASE_URL` env var; defaults to `http://localhost:4173`.
- In CI, the app is built and served via `npm run preview` before tests.
