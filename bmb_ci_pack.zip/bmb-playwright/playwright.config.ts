
import { defineConfig, devices } from '@playwright/test';
const baseURL = process.env.BASE_URL || 'http://localhost:4173';
export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  use: { baseURL, trace: 'retain-on-failure', screenshot: 'only-on-failure', video: 'retain-on-failure' },
  webServer: { command: 'npm run preview', port: 4173, reuseExistingServer: false },
  projects: [{ name:'chromium', use: { ...devices['Desktop Chrome'] } }],
});
